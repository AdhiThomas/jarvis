# Debug builds only for now; no custom rules needed.
