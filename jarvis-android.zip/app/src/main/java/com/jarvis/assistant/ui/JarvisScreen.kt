package com.jarvis.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.MainViewModel
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.time.format.TextStyle as JavaTextStyle

private const val MAX_LINES_PER_PANEL = 2

@Composable
fun JarvisScreen(vm: MainViewModel, onOpenSetup: () -> Unit) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val reminders by vm.reminders.collectAsStateWithLifecycle()
    val plans by vm.plans.collectAsStateWithLifecycle()
    val lastSpoken by vm.tts.lastSpoken.collectAsStateWithLifecycle()

    var listening by rememberSaveable { mutableStateOf(false) }

    // Real system clock, refreshed on every second boundary.
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now()
            delay(1000L - (System.currentTimeMillis() % 1000L))
        }
    }

    val timeFormat = remember { DateTimeFormatter.ofPattern("hh:mm a", Locale.US) }
    val dateFormat = remember { DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.US) }
    val reminderFormat = remember { DateTimeFormatter.ofPattern("dd.MM hh:mm a", Locale.US) }
    val dayName = now.dayOfWeek.getDisplayName(JavaTextStyle.FULL, Locale.getDefault())

    Box(
        Modifier
            .fillMaxSize()
            .background(Hud.Black)
            .systemBarsPadding()
            .hudBackdrop()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 22.dp, vertical = 24.dp)
        ) {
            // ---- Header: real date (left), setup gear, real time (right) ----
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = smallCaps(dayName, 30.sp, 22.sp),
                        color = Hud.CyanBright,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = now.format(dateFormat),
                        style = TextStyle(
                            color = Hud.CyanBright.copy(alpha = 0.85f),
                            fontSize = 22.sp,
                            fontFeatureSettings = "tnum"
                        ),
                        maxLines = 1
                    )
                }
                Box(
                    Modifier
                        .clickable(onClickLabel = "Open setup", onClick = onOpenSetup)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    HudIconView(icon = HudIcon.GEAR, iconSize = 26.dp, color = Hud.Cyan)
                }
                Text(
                    text = now.format(timeFormat),
                    style = TextStyle(
                        color = Hud.CyanBright,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Medium,
                        fontFeatureSettings = "tnum"
                    ),
                    maxLines = 1,
                    softWrap = false
                )
            }

            Spacer(Modifier.height(14.dp))

            HudPanel(title = "Today’s Task", icon = HudIcon.CHECK) {
                PanelLines(
                    lines = tasks.map { it.title },
                    emptyText = "No tasks yet"
                )
            }

            // ---- Orb ----
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val orbSize = minOf(maxWidth, maxHeight) * 0.92f

                Canvas(Modifier.fillMaxSize()) {
                    val cy = size.height / 2f
                    val edge = orbSize.toPx() / 2f
                    val left = size.width / 2f - edge
                    val right = size.width / 2f + edge
                    val sw = 2.dp.toPx()
                    drawLine(
                        color = Hud.Cyan.copy(alpha = 0.55f),
                        start = Offset(0f, cy),
                        end = Offset(left, cy),
                        strokeWidth = sw,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Hud.Cyan.copy(alpha = 0.55f),
                        start = Offset(right, cy),
                        end = Offset(size.width, cy),
                        strokeWidth = sw,
                        cap = StrokeCap.Round
                    )
                }

                Orb(
                    listening = listening,
                    onClick = { listening = !listening },
                    modifier = Modifier.size(orbSize)
                )
            }

            // ---- Caption: latest spoken text ----
            val caption = when {
                listening -> "Listening state. Voice input arrives in Step 2."
                lastSpoken.isNotBlank() -> lastSpoken
                else -> "Nothing spoken yet."
            }
            Text(
                text = caption,
                color = if (lastSpoken.isNotBlank() && !listening) Hud.CyanBright else Hud.CyanMuted,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )

            HudPanel(title = "Reminders", icon = HudIcon.BELL) {
                PanelLines(
                    lines = reminders.map { r ->
                        val whenText = Instant.ofEpochMilli(r.triggerAt)
                            .atZone(ZoneId.systemDefault())
                            .format(reminderFormat)
                        "$whenText  ${r.text}"
                    },
                    emptyText = "No reminders yet"
                )
            }

            Spacer(Modifier.height(14.dp))

            HudPanel(title = "Plans Today", icon = HudIcon.LIST) {
                PanelLines(
                    lines = plans.map { p ->
                        val whenText = Instant.ofEpochMilli(p.startAt)
                            .atZone(ZoneId.systemDefault())
                            .format(timeFormat)
                        "$whenText  ${p.title}"
                    },
                    emptyText = "Nothing planned today"
                )
            }
        }
    }
}

/** Shows up to [MAX_LINES_PER_PANEL] entries, or a clean empty state. */
@Composable
private fun PanelLines(lines: List<String>, emptyText: String) {
    if (lines.isEmpty()) {
        Text(
            text = emptyText,
            color = Hud.CyanDim,
            fontSize = 15.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        for (line in lines.take(MAX_LINES_PER_PANEL)) {
            Text(
                text = line,
                color = Hud.CyanBright,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        val extra = lines.size - MAX_LINES_PER_PANEL
        if (extra > 0) {
            Text(text = "+$extra more", color = Hud.CyanMuted, fontSize = 12.sp)
        }
    }
}
