package com.jarvis.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import com.jarvis.assistant.data.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceOption(
    val name: String,
    val label: String,
    val language: String,
    val needsNetwork: Boolean
)

/** Thin wrapper around Android's TextToSpeech using the phone's installed voices. */
class TtsController(context: Context, private val settings: SettingsStore) {

    private var engine: TextToSpeech? = null
    private val voiceMap = HashMap<String, Voice>()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _voices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val voices: StateFlow<List<VoiceOption>> = _voices.asStateFlow()

    private val _lastSpoken = MutableStateFlow("")
    val lastSpoken: StateFlow<String> = _lastSpoken.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                onEngineReady()
            } else {
                _error.value =
                    "No text-to-speech engine could be started. Install or enable one in Android settings."
            }
        }
    }

    private fun onEngineReady() {
        val e = engine ?: return
        try {
            val all: Set<Voice> = e.voices ?: emptySet()
            voiceMap.clear()
            for (v in all) {
                voiceMap[v.name] = v
            }
            _voices.value = all
                .map {
                    VoiceOption(
                        name = it.name,
                        label = it.locale.displayName + " · " + it.name,
                        language = it.locale.language,
                        needsNetwork = it.isNetworkConnectionRequired
                    )
                }
                .sortedBy { it.label }
        } catch (ex: Exception) {
            _voices.value = emptyList()
        }
        applyVoice(settings.voiceName)
        e.setSpeechRate(settings.speechRate)
        e.setPitch(settings.pitch)
        _ready.value = true
    }

    /** Empty name selects the engine's default voice. */
    fun applyVoice(name: String) {
        val e = engine ?: return
        try {
            if (name.isBlank()) {
                val default = e.defaultVoice
                if (default != null) e.setVoice(default)
            } else {
                val voice = voiceMap[name]
                if (voice != null) e.setVoice(voice)
            }
        } catch (ex: Exception) {
            // Some engines throw if a voice is unavailable; keep the current voice.
        }
    }

    fun setRate(rate: Float) {
        engine?.setSpeechRate(rate)
    }

    fun setPitch(pitch: Float) {
        engine?.setPitch(pitch)
    }

    fun speak(text: String) {
        val e = engine
        if (e == null || !_ready.value) {
            _error.value = "Text-to-speech is not ready yet."
            return
        }
        val result = e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-utterance")
        if (result == TextToSpeech.ERROR) {
            _error.value = "The text-to-speech engine could not speak."
        } else {
            _error.value = null
            _lastSpoken.value = text
        }
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        _ready.value = false
    }
}
