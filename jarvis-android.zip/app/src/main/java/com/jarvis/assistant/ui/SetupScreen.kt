package com.jarvis.assistant.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.MainViewModel
import com.jarvis.assistant.VoiceOption
import java.util.Locale

private enum class PermKind { RUNTIME, NOTIFICATIONS, ACCESSIBILITY }

private data class PermSpec(
    val id: String,
    val title: String,
    val purpose: String,
    val kind: PermKind,
    val permissions: List<String> = emptyList(),
    val notUsedYet: Boolean = false
)

private fun permissionSpecs(): List<PermSpec> = listOf(
    PermSpec(
        id = "mic",
        title = "Microphone",
        purpose = "Hear your voice commands.",
        kind = PermKind.RUNTIME,
        permissions = listOf(android.Manifest.permission.RECORD_AUDIO)
    ),
    PermSpec(
        id = "notifications",
        title = "Notifications",
        purpose = "Show reminder alerts.",
        kind = PermKind.NOTIFICATIONS,
        permissions = if (Build.VERSION.SDK_INT >= 33) {
            listOf(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            emptyList()
        }
    ),
    PermSpec(
        id = "calendar",
        title = "Calendar",
        purpose = "Read and add calendar events.",
        kind = PermKind.RUNTIME,
        permissions = listOf(
            android.Manifest.permission.READ_CALENDAR,
            android.Manifest.permission.WRITE_CALENDAR
        )
    ),
    PermSpec(
        id = "camera",
        title = "Camera",
        purpose = "Not used by any feature yet. Optional.",
        kind = PermKind.RUNTIME,
        permissions = listOf(android.Manifest.permission.CAMERA),
        notUsedYet = true
    ),
    PermSpec(
        id = "accessibility",
        title = "Accessibility",
        purpose = "Not used yet. JARVIS has no accessibility service in this version, " +
            "so it will not appear in Android's list until a later step adds one.",
        kind = PermKind.ACCESSIBILITY,
        notUsedYet = true
    )
)

private fun isGranted(context: Context, spec: PermSpec): Boolean = when (spec.kind) {
    PermKind.RUNTIME -> spec.permissions.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    PermKind.NOTIFICATIONS -> NotificationManagerCompat.from(context).areNotificationsEnabled()

    PermKind.ACCESSIBILITY -> {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        enabled.split(':').any { it.startsWith(context.packageName + "/") }
    }
}

private fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

private fun safeStart(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        // Settings screen not available on this device; nothing else to do.
    }
}

private fun appDetailsIntent(context: Context): Intent =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))

private fun notificationSettingsIntent(context: Context): Intent =
    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)

@Composable
fun SetupScreen(vm: MainViewModel, onEnter: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Hud.Black)
            .systemBarsPadding()
            .hudBackdrop()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "J.A.R.V.I.S.",
                    color = Hud.CyanBright,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = smallCaps("Setup", 24.sp, 18.sp),
                    color = Hud.Cyan,
                    letterSpacing = 2.sp
                )
            }

            PermissionsSection()
            AboutSection(vm)
            VoiceSection(vm)
            OpenRouterSection(vm)

            HudButton(
                text = "Enter JARVIS",
                onClick = onEnter,
                big = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ---- Permissions -------------------------------------------------------------------

@Composable
private fun PermissionsSection() {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val specs = remember { permissionSpecs() }

    var tick by remember { mutableIntStateOf(0) }
    val permanentlyDenied: SnapshotStateMap<String, Boolean> = remember { mutableStateMapOf() }
    var pending by remember { mutableStateOf<PermSpec?>(null) }

    // Re-check live whenever the user returns from a system dialog or the Settings app.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val spec = pending
        if (spec != null && activity != null) {
            val denied = spec.permissions.filter { result[it] != true }
            if (denied.isNotEmpty()) {
                permanentlyDenied[spec.id] = denied.any {
                    !ActivityCompat.shouldShowRequestPermissionRationale(activity, it)
                }
            }
        }
        pending = null
        tick++
    }

    HudPanel(title = "Permissions", icon = null, brackets = false) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            for (spec in specs) {
                val granted = remember(tick, spec) { isGranted(context, spec) }

                val needsSettings = !granted && when (spec.kind) {
                    PermKind.ACCESSIBILITY -> true
                    PermKind.NOTIFICATIONS ->
                        Build.VERSION.SDK_INT < 33 || permanentlyDenied[spec.id] == true
                    PermKind.RUNTIME -> permanentlyDenied[spec.id] == true
                }

                val statusText = when {
                    granted -> "Granted"
                    spec.kind == PermKind.ACCESSIBILITY -> "Not enabled"
                    else -> "Not granted"
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = spec.title,
                                color = Hud.CyanBright,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = statusText,
                                color = if (granted) Hud.Ok else Hud.Warn,
                                fontSize = 13.sp
                            )
                        }
                        Text(
                            text = spec.purpose,
                            color = Hud.CyanMuted,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    if (!granted) {
                        HudButton(
                            text = if (needsSettings) "Open settings" else "Grant",
                            onClick = {
                                when {
                                    spec.kind == PermKind.ACCESSIBILITY ->
                                        safeStart(context, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

                                    spec.kind == PermKind.NOTIFICATIONS && Build.VERSION.SDK_INT < 33 ->
                                        safeStart(context, notificationSettingsIntent(context))

                                    needsSettings ->
                                        safeStart(context, appDetailsIntent(context))

                                    else -> {
                                        pending = spec
                                        launcher.launch(spec.permissions.toTypedArray())
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

// ---- About me ----------------------------------------------------------------------

@Composable
private fun AboutSection(vm: MainViewModel) {
    HudPanel(title = "About Me", icon = null, brackets = false) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            HudField(
                label = "Your name",
                value = vm.userName,
                onValueChange = vm::updateUserName,
                placeholder = "What should JARVIS call you?"
            )
            HudField(
                label = "About you",
                value = vm.aboutMe,
                onValueChange = vm::updateAboutMe,
                placeholder = "Anything JARVIS should know about you",
                singleLine = false,
                minLines = 4
            )
            Text(
                text = "Saved on this phone only.",
                color = Hud.CyanMuted,
                fontSize = 12.sp
            )
        }
    }
}

// ---- Voice -------------------------------------------------------------------------

@Composable
private fun VoiceSection(vm: MainViewModel) {
    val voices by vm.tts.voices.collectAsStateWithLifecycle()
    val ready by vm.tts.ready.collectAsStateWithLifecycle()
    val error by vm.tts.error.collectAsStateWithLifecycle()
    var showDialog by remember { mutableStateOf(false) }

    val currentLabel = when {
        vm.voiceName.isBlank() -> "System default"
        else -> voices.firstOrNull { it.name == vm.voiceName }?.label ?: vm.voiceName
    }

    HudPanel(title = "Voice", icon = null, brackets = false) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = smallCaps("Selected voice", 14.sp, 11.sp),
                color = Hud.CyanMuted,
                letterSpacing = 1.sp
            )
            Text(
                text = currentLabel,
                color = Hud.CyanBright,
                fontSize = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            HudButton(
                text = if (ready) "Choose voice (${voices.size})" else "Loading voices...",
                onClick = { showDialog = true },
                enabled = ready,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Speed " + String.format(Locale.US, "%.2f", vm.speechRate) + "x",
                color = Hud.CyanBright,
                fontSize = 14.sp
            )
            Slider(
                value = vm.speechRate,
                onValueChange = vm::updateSpeechRate,
                valueRange = 0.5f..2.0f,
                colors = hudSliderColors()
            )

            Text(
                text = "Pitch " + String.format(Locale.US, "%.2f", vm.pitch),
                color = Hud.CyanBright,
                fontSize = 14.sp
            )
            Slider(
                value = vm.pitch,
                onValueChange = vm::updatePitch,
                valueRange = 0.5f..2.0f,
                colors = hudSliderColors()
            )

            HudButton(
                text = "Test voice",
                onClick = vm::testVoice,
                enabled = ready,
                modifier = Modifier.fillMaxWidth()
            )

            if (error != null) {
                Text(text = error ?: "", color = Hud.Warn, fontSize = 13.sp)
            }
        }
    }

    if (showDialog) {
        VoiceDialog(
            options = voices,
            selected = vm.voiceName,
            onSelect = {
                vm.selectVoice(it)
                showDialog = false
            },
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
private fun hudSliderColors() = SliderDefaults.colors(
    thumbColor = Hud.Cyan,
    activeTrackColor = Hud.Cyan,
    inactiveTrackColor = Hud.CyanDim.copy(alpha = 0.45f)
)

@Composable
private fun VoiceDialog(
    options: List<VoiceOption>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var allLanguages by remember { mutableStateOf(false) }
    val deviceLanguage = remember { Locale.getDefault().language }
    val shown = remember(options, allLanguages) {
        if (allLanguages) options else options.filter { it.language == deviceLanguage }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .background(Hud.Black, CutCornerShape(16.dp))
                .hudBorder(shape = CutCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = smallCaps("Choose Voice", 22.sp, 17.sp),
                color = Hud.CyanBright,
                letterSpacing = 1.sp
            )
            HudButton(
                text = if (allLanguages) "Show my language only" else "Show all languages",
                onClick = { allLanguages = !allLanguages },
                modifier = Modifier.fillMaxWidth()
            )
            LazyColumn(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
            ) {
                item(key = "system-default") {
                    VoiceRow(label = "System default", selected = selected.isBlank()) { onSelect("") }
                }
                items(shown, key = { it.name }) { option ->
                    VoiceRow(
                        label = option.label + if (option.needsNetwork) " (online)" else "",
                        selected = option.name == selected
                    ) { onSelect(option.name) }
                }
            }
            if (shown.isEmpty()) {
                Text(
                    text = "No installed voices match your language. Try \"Show all languages\".",
                    color = Hud.CyanMuted,
                    fontSize = 13.sp
                )
            }
            HudButton(text = "Close", onClick = onDismiss, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun VoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = (if (selected) "> " else "   ") + label,
        color = if (selected) Hud.Cyan else Hud.CyanBright,
        fontSize = 14.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp)
    )
}

// ---- OpenRouter --------------------------------------------------------------------

@Composable
private fun OpenRouterSection(vm: MainViewModel) {
    var showKey by remember { mutableStateOf(false) }

    HudPanel(title = "OpenRouter", icon = null, brackets = false) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            HudField(
                label = "API key",
                value = vm.apiKeyDraft,
                onValueChange = vm::updateApiKeyDraft,
                placeholder = "Paste your OpenRouter key",
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            HudField(
                label = "Model ID",
                value = vm.modelIdDraft,
                onValueChange = vm::updateModelIdDraft,
                placeholder = "e.g. provider/model-name",
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudButton(
                    text = if (showKey) "Hide key" else "Show key",
                    onClick = { showKey = !showKey },
                    modifier = Modifier.weight(1f)
                )
                HudButton(
                    text = "Save",
                    onClick = vm::saveOpenRouter,
                    enabled = vm.openRouterDirty,
                    modifier = Modifier.weight(1f)
                )
            }

            val error = vm.saveError
            when {
                error != null -> Text(text = error, color = Hud.Warn, fontSize = 13.sp)
                vm.openRouterDirty -> Text(text = "Unsaved changes.", color = Hud.Warn, fontSize = 13.sp)
                vm.openRouterConfigured -> Text(
                    text = "Saved on this phone, encrypted with the Android Keystore.",
                    color = Hud.Ok,
                    fontSize = 13.sp
                )
                else -> Text(text = "Not set yet.", color = Hud.CyanMuted, fontSize = 13.sp)
            }
            Text(
                text = "The key is never part of the app code. Nothing is sent anywhere in this version.",
                color = Hud.CyanMuted,
                fontSize = 12.sp
            )
        }
    }
}
