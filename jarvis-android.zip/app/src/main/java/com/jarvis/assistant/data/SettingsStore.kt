package com.jarvis.assistant.data

import android.content.Context

/** Plain settings in SharedPreferences, secrets delegated to [SecureStore]. */
class SettingsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
    private val secure = SecureStore(context)

    var setupDone: Boolean
        get() = prefs.getBoolean("setup_done", false)
        set(value) = prefs.edit().putBoolean("setup_done", value).apply()

    var userName: String
        get() = prefs.getString("user_name", "") ?: ""
        set(value) = prefs.edit().putString("user_name", value).apply()

    var aboutMe: String
        get() = prefs.getString("about_me", "") ?: ""
        set(value) = prefs.edit().putString("about_me", value).apply()

    /** Empty string means "system default voice". */
    var voiceName: String
        get() = prefs.getString("voice_name", "") ?: ""
        set(value) = prefs.edit().putString("voice_name", value).apply()

    var speechRate: Float
        get() = prefs.getFloat("speech_rate", 1.0f)
        set(value) = prefs.edit().putFloat("speech_rate", value).apply()

    var pitch: Float
        get() = prefs.getFloat("pitch", 1.0f)
        set(value) = prefs.edit().putFloat("pitch", value).apply()

    fun readApiKey(): String = secure.get("openrouter_api_key")
    fun readModelId(): String = secure.get("openrouter_model_id")

    fun saveOpenRouter(apiKey: String, modelId: String): Boolean {
        val keyOk = secure.put("openrouter_api_key", apiKey)
        val modelOk = secure.put("openrouter_model_id", modelId)
        return keyOk && modelOk
    }
}
