package com.jarvis.assistant.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.R

/**
 * The J.A.R.V.I.S. orb. Never rotates (so the text stays upright).
 * Idle: slow glow pulse. Listening: faster, stronger pulse plus an expanding ring.
 */
@Composable
fun Orb(listening: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }

    // key() restarts the animation cleanly when the duration changes between states.
    key(listening) {
        val transition = rememberInfiniteTransition(label = "orbPulse")
        val pulse by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = if (listening) 650 else 3200,
                    easing = FastOutSlowInEasing
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        )

        Box(
            modifier = modifier
                .drawBehind {
                    val p = pulse
                    val r = size.minDimension / 2f
                    val glowAlpha = if (listening) 0.45f + 0.45f * p else 0.16f + 0.30f * p
                    val glowRadius = r * 1.45f
                    drawCircle(
                        brush = Brush.radialGradient(
                            0.60f to Color.Transparent,
                            0.69f to Hud.Cyan.copy(alpha = glowAlpha),
                            1.00f to Color.Transparent,
                            center = center,
                            radius = glowRadius
                        ),
                        radius = glowRadius,
                        center = center
                    )
                    if (listening) {
                        drawCircle(
                            color = Hud.CyanBright.copy(alpha = (1f - p) * 0.6f),
                            radius = r * (1.0f + 0.22f * p),
                            center = center,
                            style = Stroke(2.dp.toPx())
                        )
                    }
                }
                .clip(CircleShape)
                .clickable(
                    interactionSource = interaction,
                    indication = null,
                    role = Role.Button,
                    onClickLabel = "Toggle listening state",
                    onClick = onClick
                )
        ) {
            Image(
                painter = painterResource(R.drawable.jarvis_orb),
                contentDescription = "J.A.R.V.I.S. orb",
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val s = if (listening) 1f + 0.035f * pulse else 1f + 0.012f * pulse
                        scaleX = s
                        scaleY = s
                    }
            )
        }
    }
}
