package com.jarvis.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object Hud {
    val Black = Color(0xFF000000)
    val Cyan = Color(0xFF22C8FF)
    val CyanBright = Color(0xFF7FE6FF)
    val CyanMuted = Color(0xFF58B8DA)
    val CyanDim = Color(0xFF1C7FA8)
    val Ok = Color(0xFF3DFFB0)
    val Warn = Color(0xFFFFB347)
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Hud.Cyan,
            onPrimary = Hud.Black,
            background = Hud.Black,
            onBackground = Hud.CyanBright,
            surface = Hud.Black,
            onSurface = Hud.CyanBright
        ),
        content = content
    )
}

/** Glowing outline in any shape (used with CutCornerShape for the HUD look). */
fun Modifier.hudBorder(
    shape: Shape = CutCornerShape(12.dp),
    color: Color = Hud.Cyan,
    width: Dp = 1.5.dp,
    glow: Boolean = true
): Modifier = this.drawWithCache {
    val outline = shape.createOutline(size, layoutDirection, this)
    val path = Path()
    when (outline) {
        is Outline.Generic -> path.addPath(outline.path)
        is Outline.Rectangle -> path.addRect(outline.rect)
        is Outline.Rounded -> path.addRoundRect(outline.roundRect)
    }
    val strokeWidth = width.toPx()
    onDrawBehind {
        if (glow) {
            drawPath(path, color.copy(alpha = 0.10f), style = Stroke(strokeWidth * 7f))
            drawPath(path, color.copy(alpha = 0.22f), style = Stroke(strokeWidth * 3.5f))
        }
        drawPath(path, color, style = Stroke(strokeWidth))
    }
}

/** Big outer HUD frame with cut corners, drawn behind a whole screen. */
fun Modifier.hudBackdrop(): Modifier = this.drawBehind {
    val inset = 6.dp.toPx()
    val cut = 34.dp.toPx()
    val w = size.width
    val h = size.height
    val frame = Path().apply {
        moveTo(inset + cut, inset)
        lineTo(w - inset - cut, inset)
        lineTo(w - inset, inset + cut)
        lineTo(w - inset, h - inset - cut)
        lineTo(w - inset - cut, h - inset)
        lineTo(inset + cut, h - inset)
        lineTo(inset, h - inset - cut)
        lineTo(inset, inset + cut)
        close()
    }
    val sw = 1.5.dp.toPx()
    drawPath(frame, Hud.Cyan.copy(alpha = 0.10f), style = Stroke(sw * 7f))
    drawPath(frame, Hud.Cyan.copy(alpha = 0.22f), style = Stroke(sw * 3.5f))
    drawPath(frame, Hud.Cyan, style = Stroke(sw))

    // Short bright accents at the top and bottom centre, like the mockup.
    val accent = 56.dp.toPx()
    val mid = w / 2f
    for (y in listOf(inset, h - inset)) {
        drawLine(
            color = Hud.CyanBright,
            start = Offset(mid - accent, y),
            end = Offset(mid + accent, y),
            strokeWidth = sw * 2.2f,
            cap = StrokeCap.Round
        )
    }
}

/** Small caps made from real text: first letter of each word large, the rest smaller capitals. */
fun smallCaps(text: String, big: TextUnit, small: TextUnit): AnnotatedString = buildAnnotatedString {
    var newWord = true
    for (ch in text) {
        if (ch.isLetter() && !newWord) {
            withStyle(SpanStyle(fontSize = small)) { append(ch.uppercaseChar()) }
        } else {
            withStyle(SpanStyle(fontSize = big)) {
                append(if (ch.isLetter()) ch.uppercaseChar() else ch)
            }
        }
        newWord = !ch.isLetterOrDigit() && ch != '\'' && ch != '’'
    }
}

enum class HudIcon { CHECK, BELL, LIST, GEAR }

@Composable
fun HudIconView(icon: HudIcon, iconSize: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(iconSize)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (icon) {
            HudIcon.CHECK -> {
                drawCircle(color = color, radius = w * 0.45f, style = stroke)
                val tick = Path().apply {
                    moveTo(w * 0.28f, h * 0.52f)
                    lineTo(w * 0.44f, h * 0.68f)
                    lineTo(w * 0.74f, h * 0.34f)
                }
                drawPath(tick, color, style = stroke)
            }

            HudIcon.BELL -> {
                val bell = Path().apply {
                    moveTo(w * 0.18f, h * 0.76f)
                    lineTo(w * 0.82f, h * 0.76f)
                    cubicTo(w * 0.70f, h * 0.66f, w * 0.72f, h * 0.52f, w * 0.72f, h * 0.44f)
                    cubicTo(w * 0.72f, h * 0.24f, w * 0.28f, h * 0.24f, w * 0.28f, h * 0.44f)
                    cubicTo(w * 0.28f, h * 0.52f, w * 0.30f, h * 0.66f, w * 0.18f, h * 0.76f)
                    close()
                }
                drawPath(bell, color, style = stroke)
                drawLine(
                    color = color,
                    start = Offset(w * 0.5f, h * 0.10f),
                    end = Offset(w * 0.5f, h * 0.22f),
                    strokeWidth = w * 0.09f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = color,
                    start = Offset(w * 0.42f, h * 0.88f),
                    end = Offset(w * 0.58f, h * 0.88f),
                    strokeWidth = w * 0.09f,
                    cap = StrokeCap.Round
                )
            }

            HudIcon.LIST -> {
                for (i in 0..2) {
                    val y = h * (0.22f + 0.28f * i)
                    drawCircle(color = color, radius = w * 0.07f, center = Offset(w * 0.12f, y))
                    drawLine(
                        color = color,
                        start = Offset(w * 0.30f, y),
                        end = Offset(w * 0.92f, y),
                        strokeWidth = w * 0.09f,
                        cap = StrokeCap.Round
                    )
                }
            }

            HudIcon.GEAR -> {
                val c = Offset(w / 2f, h / 2f)
                drawCircle(color = color, radius = w * 0.15f, center = c, style = stroke)
                drawCircle(color = color, radius = w * 0.30f, center = c, style = stroke)
                for (i in 0 until 8) {
                    val a = i * PI / 4.0
                    val dx = cos(a).toFloat()
                    val dy = sin(a).toFloat()
                    drawLine(
                        color = color,
                        start = Offset(c.x + dx * w * 0.32f, c.y + dy * h * 0.32f),
                        end = Offset(c.x + dx * w * 0.46f, c.y + dy * h * 0.46f),
                        strokeWidth = w * 0.12f,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun HudButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    big: Boolean = false,
    accent: Color = Hud.Cyan
) {
    val tint = if (enabled) accent else Hud.CyanDim.copy(alpha = 0.6f)
    val shape = CutCornerShape(if (big) 16.dp else 8.dp)
    Box(
        modifier = modifier
            .hudBorder(shape = shape, color = tint, glow = enabled)
            .clip(shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (big) 16.dp else 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (big) smallCaps(text, 22.sp, 17.sp) else smallCaps(text, 15.sp, 12.sp),
            color = tint,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp,
            maxLines = 1
        )
    }
}

@Composable
fun HudField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    singleLine: Boolean = true,
    minLines: Int = 1,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default
) {
    Column(modifier.fillMaxWidth()) {
        Text(
            text = smallCaps(label, 14.sp, 11.sp),
            color = Hud.CyanMuted,
            letterSpacing = 1.sp
        )
        Box(
            Modifier
                .padding(top = 4.dp)
                .fillMaxWidth()
                .hudBorder(shape = CutCornerShape(10.dp), glow = false)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            if (value.isEmpty() && placeholder.isNotEmpty()) {
                Text(
                    text = placeholder,
                    color = Hud.CyanDim,
                    fontSize = 16.sp
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = singleLine,
                minLines = minLines,
                textStyle = TextStyle(color = Hud.CyanBright, fontSize = 16.sp),
                cursorBrush = SolidColor(Hud.Cyan),
                visualTransformation = visualTransformation,
                keyboardOptions = keyboardOptions
            )
        }
    }
}

/** Titled HUD panel: a tab with icon and title above a cut-corner body. */
@Composable
fun HudPanel(
    title: String,
    icon: HudIcon?,
    modifier: Modifier = Modifier,
    brackets: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .padding(start = 26.dp)
                .hudBorder(shape = CutCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .padding(horizontal = 14.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                HudIconView(icon = icon, iconSize = 20.dp, color = Hud.Cyan)
                Spacer(Modifier.width(8.dp))
            }
            Text(
                text = smallCaps(title, 20.sp, 15.sp),
                color = Hud.CyanBright,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                maxLines = 1
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .hudBorder(shape = CutCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (brackets) {
                Text("[", color = Hud.Cyan, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp),
                verticalArrangement = Arrangement.Center,
                content = content
            )
            if (brackets) {
                Text("]", color = Hud.Cyan, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
        }
    }
}
