package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ui.JarvisScreen
import com.jarvis.assistant.ui.JarvisTheme
import com.jarvis.assistant.ui.SetupScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisTheme {
                JarvisApp()
            }
        }
    }
}

@Composable
fun JarvisApp(vm: MainViewModel = viewModel()) {
    // First launch shows Setup. Afterwards the gear icon on the JARVIS screen reopens it.
    var showSetup by rememberSaveable { mutableStateOf(!vm.setupDone) }

    if (showSetup) {
        BackHandler(enabled = vm.setupDone) { showSetup = false }
        SetupScreen(
            vm = vm,
            onEnter = {
                vm.markSetupDone()
                showSetup = false
            }
        )
    } else {
        JarvisScreen(vm = vm, onOpenSetup = { showSetup = true })
    }
}
