package com.jarvis.assistant

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.data.JarvisDatabase
import com.jarvis.assistant.data.PlanEntity
import com.jarvis.assistant.data.ReminderEntity
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.data.TaskEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SettingsStore(app)
    private val db = JarvisDatabase.get(app)
    val tts = TtsController(app, settings)

    // ---- Setup state -------------------------------------------------------------

    var setupDone by mutableStateOf(settings.setupDone)
        private set

    var userName by mutableStateOf(settings.userName)
        private set

    var aboutMe by mutableStateOf(settings.aboutMe)
        private set

    var voiceName by mutableStateOf(settings.voiceName)
        private set

    var speechRate by mutableFloatStateOf(settings.speechRate)
        private set

    var pitch by mutableFloatStateOf(settings.pitch)
        private set

    private var savedApiKey by mutableStateOf(settings.readApiKey())
    private var savedModelId by mutableStateOf(settings.readModelId())

    var apiKeyDraft by mutableStateOf(savedApiKey)
        private set

    var modelIdDraft by mutableStateOf(savedModelId)
        private set

    var saveError by mutableStateOf<String?>(null)
        private set

    val openRouterDirty: Boolean
        get() = apiKeyDraft.trim() != savedApiKey || modelIdDraft.trim() != savedModelId

    val openRouterConfigured: Boolean
        get() = savedApiKey.isNotBlank() && savedModelId.isNotBlank()

    fun markSetupDone() {
        setupDone = true
        settings.setupDone = true
    }

    fun updateUserName(value: String) {
        userName = value
        settings.userName = value
    }

    fun updateAboutMe(value: String) {
        aboutMe = value
        settings.aboutMe = value
    }

    fun selectVoice(name: String) {
        voiceName = name
        settings.voiceName = name
        tts.applyVoice(name)
    }

    fun updateSpeechRate(value: Float) {
        speechRate = value
        settings.speechRate = value
        tts.setRate(value)
    }

    fun updatePitch(value: Float) {
        pitch = value
        settings.pitch = value
        tts.setPitch(value)
    }

    fun testVoice() {
        val name = userName.trim()
        val text = if (name.isEmpty()) "Hello. This is how I sound." else "Hello $name. This is how I sound."
        tts.speak(text)
    }

    fun updateApiKeyDraft(value: String) {
        apiKeyDraft = value
    }

    fun updateModelIdDraft(value: String) {
        modelIdDraft = value
    }

    fun saveOpenRouter() {
        val key = apiKeyDraft.trim()
        val model = modelIdDraft.trim()
        val ok = settings.saveOpenRouter(key, model)
        if (ok) {
            savedApiKey = key
            savedModelId = model
            apiKeyDraft = key
            modelIdDraft = model
            saveError = null
        } else {
            saveError = "Could not store the values securely on this phone."
        }
    }

    // ---- Panels (local database, no sample data) ----------------------------------

    val tasks: StateFlow<List<TaskEntity>> = db.taskDao().openTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = db.reminderDao().upcoming()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val dayKey = MutableStateFlow(LocalDate.now().toEpochDay())

    val plans: StateFlow<List<PlanEntity>> = dayKey
        .flatMapLatest { epochDay ->
            val zone = ZoneId.systemDefault()
            val day = LocalDate.ofEpochDay(epochDay)
            val from = day.atStartOfDay(zone).toInstant().toEpochMilli()
            val to = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            db.planDao().plansBetween(from, to)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // Roll "Plans Today" over when the date changes.
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                val today = LocalDate.now().toEpochDay()
                if (today != dayKey.value) dayKey.value = today
            }
        }
    }

    override fun onCleared() {
        tts.shutdown()
        super.onCleared()
    }
}
