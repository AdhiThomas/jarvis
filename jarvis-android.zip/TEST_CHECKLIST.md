# JARVIS Step 1 test checklist

## Build
- [ ] Push the repo to GitHub, open Actions, run "Build debug APK" (it also runs on every push).
- [ ] Download the `jarvis-debug-apk` artifact, unzip, install `app-debug.apk` (allow "install unknown apps").
- [ ] Launcher shows the JARVIS orb icon (round and adaptive masks both look right).

## First launch (Setup screen)
- [ ] Setup opens first, black background, cyan cut-corner frame.
- [ ] Microphone: shows "Not granted" -> Grant -> system dialog -> status flips to "Granted" live.
- [ ] Notifications: same flow (Android 13+ shows a dialog; older Android opens notification settings).
- [ ] Calendar: one dialog for read + write; "Granted" only when both are allowed.
- [ ] Deny a permission twice -> button changes to "Open settings"; enabling it there and coming back flips the status.
- [ ] Camera is marked "not used yet" (optional). Accessibility is marked "not used yet" and its button opens Android's Accessibility settings. It will NOT list JARVIS there yet (no service exists in Step 1).
- [ ] About me: type a name and text, force-close the app, reopen -> still there.
- [ ] Voice: "Choose voice" lists installed voices (my language first, toggle for all). Pick one, move Speed and Pitch, press "Test voice" -> you hear it.
- [ ] OpenRouter: paste key + model ID, Save -> "Saved on this phone". Key is masked; Show/Hide works. Close and reopen -> values are still there.
- [ ] "Enter JARVIS" opens the main screen.

## JARVIS screen
- [ ] Top left shows today's real weekday and date (dd.mm.yyyy). Top right shows the real time (hh:mm AM/PM) ticking every second.
- [ ] Orb pulses slowly. Tap -> stronger, faster pulse plus ring, caption says it is a listening state. Tap again -> idle. The J.A.R.V.I.S. text never rotates.
- [ ] Today's Task, Reminders, Plans Today all show clean empty states (no sample data).
- [ ] Caption under the orb is empty-state text until you press "Test voice" in Setup; then it shows the spoken sentence.
- [ ] Gear icon (next to the time) reopens Setup; "Enter JARVIS" or Back returns.
- [ ] Rotate/background/reopen: settings persist.

## Known limits in Step 1 (by design)
- No microphone input, no AI call, no way to add tasks/reminders/plans yet (the database and panels are ready; Step 2 tools will write to them).
- Tap-to-listen is only a visual state.
- Accessibility cannot be granted until a later step adds an accessibility service.
