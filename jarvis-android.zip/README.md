# JARVIS (Step 1: skeleton + Setup and JARVIS screens)

Kotlin + Jetpack Compose, single module, minSdk 26. No Gradle wrapper on purpose: the GitHub Actions
workflow installs JDK 17, the Android SDK and a pinned Gradle (8.9) and runs `gradle assembleDebug`.

Upload this folder's contents to a GitHub repo (the `.github` folder must be at the repo root),
then open the Actions tab. The debug APK is attached to each run as `jarvis-debug-apk`.

Versions: Gradle 8.9, AGP 8.5.2, Kotlin 1.9.24, KSP 1.9.24-1.0.20, Compose compiler 1.5.14,
Compose BOM 2024.09.00, Room 2.6.1, compileSdk/targetSdk 34.

API keys are never in the code. Paste your OpenRouter key and model ID in the Setup screen; they are
encrypted with an Android Keystore key on the phone.
