// Version matrix (all mutually compatible):
//   Gradle 8.9 | AGP 8.5.2 | Kotlin 1.9.24 | KSP 1.9.24-1.0.20
//   Compose compiler 1.5.14 (matches Kotlin 1.9.24) | Compose BOM 2024.09.00
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}
