package com.adhi.jarvis

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.PI
import kotlin.math.sin

/** The holographic HUD: black screen, glowing blue core. Long-press or Back to leave. */
class HudActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val v = HudView(this)
        v.setOnLongClickListener {
            finish()
            true
        }
        setContentView(v)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}

class HudView(c: Context) : View(c) {
    private var phase = 0f
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    // radius multiplier, rotation speed, sweep degrees
    private val rings = arrayOf(
        floatArrayOf(1.15f, 1f, 70f),
        floatArrayOf(1.4f, -1.5f, 110f),
        floatArrayOf(1.7f, 0.7f, 40f)
    )

    init {
        setBackgroundColor(Color.BLACK)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.2f
        val pulse = 1f + 0.05f * sin(phase * 2f * PI.toFloat())

        val gr = base * 2.4f * pulse
        glow.shader = RadialGradient(
            cx, cy, gr,
            intArrayOf(Color.argb(150, 0, 212, 255), Color.argb(50, 0, 150, 255), Color.argb(0, 0, 100, 255)),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, gr, glow)

        val cr = base * 0.8f * pulse
        core.shader = RadialGradient(
            cx, cy, cr,
            intArrayOf(Color.WHITE, Color.argb(255, 0, 212, 255), Color.argb(255, 0, 120, 255)),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, cr, core)

        arc.strokeWidth = base * 0.05f
        arc.color = Color.argb(220, 0, 212, 255)
        for (s in rings) {
            val r = base * s[0] * pulse
            val start = phase * 360f * s[1]
            canvas.drawArc(cx - r, cy - r, cx + r, cy + r, start, s[2], false, arc)
            canvas.drawArc(cx - r, cy - r, cx + r, cy + r, start + 180f, s[2], false, arc)
        }
    }
}
