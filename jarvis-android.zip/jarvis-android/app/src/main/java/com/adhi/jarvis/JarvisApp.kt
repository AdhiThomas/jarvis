package com.adhi.jarvis

import android.app.Application

class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Engine.init(this)
    }
}
