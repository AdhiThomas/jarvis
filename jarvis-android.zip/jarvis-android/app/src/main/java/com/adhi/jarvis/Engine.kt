package com.adhi.jarvis

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Central pipeline: heard text -> Claude -> spoken reply + executed actions. */
object Engine {
    lateinit var app: Context
        private set
    lateinit var speaker: Speaker
        private set

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val history = ArrayList<Pair<String, String>>()

    val console = ArrayList<String>()
    var onLine: ((String) -> Unit)? = null

    @Volatile
    private var awaitingUntil = 0L

    private val wake = Regex("""\b(jarvis|jarvish|jarves|jervis|harvis|javis)\b""")
    private val home = Regex("""daddy(s| is)? home""")

    fun init(ctx: Context) {
        app = ctx.applicationContext
        speaker = Speaker(app)
    }

    fun hasAllFiles(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    fun granted(p: String): Boolean = app.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun say(line: String) {
        main.post {
            console.add(line)
            while (console.size > 60) console.removeAt(0)
            onLine?.invoke(line)
        }
    }

    /** Called with every utterance the microphone catches. */
    fun heard(raw: String) {
        val low = raw.lowercase(Locale.ROOT)
        val flat = low.replace("\u2019", "").replace("'", "")
        val m = wake.find(low)
        if (m != null && home.containsMatchIn(flat)) {
            daddysHome()
            return
        }
        val now = System.currentTimeMillis()
        val cmd: String = when {
            m != null -> raw.substring(minOf(raw.length, m.range.last + 1)).trim(' ', ',', '.', '!', '?', ':')
            now < awaitingUntil -> raw.trim()
            else -> return
        }
        if (cmd.isBlank()) {
            awaitingUntil = now + 12000
            say("Jarvis: Yes, Sir?")
            speaker.speak("Yes, Sir?")
            return
        }
        awaitingUntil = 0
        handleCommand(cmd)
    }

    /** Text typed into the app's command box. */
    fun typed(raw: String) {
        val flat = raw.lowercase(Locale.ROOT).replace("\u2019", "").replace("'", "")
        if (home.containsMatchIn(flat)) daddysHome() else handleCommand(raw)
    }

    private fun daddysHome() {
        val line = "Welcome home, Boss. Initiating full system interface override."
        say("Jarvis: $line")
        speaker.speak(line)
        Store.appendLog("Boss arrived home")
        Executor.run(JSONObject("""{"action":"LAUNCH_HUD_INTERFACE","theme":"jarvis_holographic"}"""))
    }

    fun handleCommand(text: String) {
        say("You: $text")
        if (Store.apiKey.isBlank()) {
            val m = "Sir, I shall need your Claude API key in my settings first."
            say("Jarvis: $m")
            speaker.speak(m)
            return
        }
        io.execute {
            try {
                val ctx = buildContext()
                val reply = Brain.ask(text, ArrayList(history), ctx)
                val (spoken, actions) = Parser.split(reply)
                history.add(Pair(text, spoken.ifBlank { "Done." }))
                while (history.size > 8) history.removeAt(0)
                main.post {
                    if (spoken.isNotBlank()) {
                        say("Jarvis: $spoken")
                        speaker.speak(spoken)
                    }
                    for (a in actions) {
                        say("[action] $a")
                        Executor.run(a)
                    }
                }
            } catch (e: Exception) {
                say("Error: ${e.message}")
                main.post { speaker.speak("My apologies, Sir. The uplink has failed.") }
            }
        }
    }

    /** Device context handed to Claude on every turn. */
    private fun buildContext(): String {
        val sb = StringBuilder()
        val now = Date()
        sb.appendLine("time=" + SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(now) +
                " (" + SimpleDateFormat("EEEE", Locale.US).format(now) + ")")

        try {
            val bi = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (lvl >= 0) sb.appendLine("battery=" + (lvl * 100 / scale) + "% charging=" + charging)
        } catch (e: Exception) {
        }

        val pkg = JarvisAccessibility.lastPackage
        if (pkg != null) {
            val label = try {
                app.packageManager.getApplicationLabel(app.packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            sb.appendLine("active_app=$label")
        }

        try {
            if (granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
                if (loc != null) sb.appendLine(String.format(Locale.US, "location=%.3f,%.3f", loc.latitude, loc.longitude))
            }
        } catch (e: Exception) {
        }

        try {
            if (granted(Manifest.permission.READ_CALENDAR)) {
                val t0 = System.currentTimeMillis()
                val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(b, t0)
                ContentUris.appendId(b, t0 + 36L * 3600 * 1000)
                val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
                val rows = ArrayList<String>()
                app.contentResolver.query(
                    b.build(),
                    arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END),
                    null, null, CalendarContract.Instances.BEGIN + " ASC"
                )?.use { c ->
                    while (c.moveToNext() && rows.size < 15) {
                        rows.add(fmt.format(Date(c.getLong(1))) + " to " + fmt.format(Date(c.getLong(2))) + " " + c.getString(0))
                    }
                }
                sb.appendLine("CALENDAR (next 36h): " + (if (rows.isEmpty()) "empty" else rows.joinToString("; ")))
            }
        } catch (e: Exception) {
        }

        try {
            if (hasAllFiles()) {
                val root = Environment.getExternalStorageDirectory()
                val names = ArrayList<String>()
                for (d in listOf("Download", "Documents")) {
                    val dir = File(root, d)
                    if (!dir.isDirectory) continue
                    dir.walkTopDown().maxDepth(2).filter { it.isFile }.take(40).forEach {
                        names.add(d + "/" + it.relativeTo(dir).path)
                    }
                }
                if (names.isNotEmpty()) sb.appendLine("FILES: " + names.joinToString("; "))
            }
        } catch (e: Exception) {
        }
        return sb.toString().trim()
    }
}
