package com.adhi.jarvis

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The J.A.R.V.I.S. screen: neon frame, live date/time, three panels and the animated reactor.
 * Blue while listening, yellow while speaking, and the reactor beats (no shaking) as he talks.
 */
class HudScreenView(ctx: Context) : View(ctx) {
    var onCore: (() -> Unit)? = null
    var onGear: (() -> Unit)? = null
    var onPanel: ((Int) -> Unit)? = null
    var onHold: (() -> Unit)? = null

    private val blue = Color.parseColor("#00D4FF")
    private val blueDeep = Color.parseColor("#0A7BFF")
    private val yellow = Color.parseColor("#FFC21A")
    private val yellowDeep = Color.parseColor("#FF9A00")

    private val core: Bitmap = BitmapFactory.decodeResource(ctx.resources, R.drawable.jarvis_core)

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val yellowFilter = tintFilter(1f)

    // animation state
    private val t0 = System.nanoTime()
    private var lastNs = t0
    private var tint = 0f
    private var rot = 0f
    private var smoothBeat = 0f

    // geometry
    private val framePath = Path()
    private val frameInner = Path()
    private val frameMeasure = PathMeasure()
    private val seg = Path()
    private val tmp = Path()
    private val dst = RectF()
    private val arcRect = RectF()
    private val panelRects = Array(3) { RectF() }
    private val panelPaths = Array(3) { Path() }
    private val gearRect = RectF()
    private var cx = 0f
    private var cy = 0f
    private var cr = 0f
    private var dividerY = 0f

    // content
    private val layouts = arrayOfNulls<StaticLayout>(3)
    private var dataKey = ""
    private var plansCache: List<String> = emptyList()
    private var plansAt = -100000L
    private val titles = arrayOf("TODAY\u2019S TASK", "REMINDERS", "PLANS TODAY")

    private val dayFmt = SimpleDateFormat("EEEE", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    private val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private var lastSec = -1L
    private var dayS = ""
    private var dateS = ""
    private var timeS = ""

    // ---------- helpers ----------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun alphaOf(color: Int, a: Float): Int =
        Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun bump(x: Float, c: Float, w: Float): Float {
        val d = (x - c) / w
        return exp(-d * d)
    }

    private fun chamfer(r: RectF, c: Float): Path = Path().apply {
        moveTo(r.left + c, r.top)
        lineTo(r.right - c, r.top)
        lineTo(r.right, r.top + c)
        lineTo(r.right, r.bottom - c)
        lineTo(r.right - c, r.bottom)
        lineTo(r.left + c, r.bottom)
        lineTo(r.left, r.bottom - c)
        lineTo(r.left, r.top + c)
        close()
    }

    /** A neon stroke: wide faint halo, medium halo, bright core. */
    private fun glowPath(c: Canvas, p: Path, color: Int, w: Float, a: Float) {
        line.style = Paint.Style.STROKE
        line.color = alphaOf(color, a * 0.08f); line.strokeWidth = w * 5f; c.drawPath(p, line)
        line.color = alphaOf(color, a * 0.18f); line.strokeWidth = w * 2.6f; c.drawPath(p, line)
        line.color = alphaOf(color, a); line.strokeWidth = w; c.drawPath(p, line)
    }

    private fun ringArc(c: Canvas, radius: Float, startDeg: Float, sweep: Float, color: Int, w: Float) {
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)
        line.style = Paint.Style.STROKE
        line.color = alphaOf(color, 0.22f); line.strokeWidth = w * 3f
        c.drawArc(arcRect, startDeg, sweep, false, line)
        line.color = alphaOf(color, 0.95f); line.strokeWidth = w
        c.drawArc(arcRect, startDeg, sweep, false, line)
    }

    /** Hue-rotates the blue artwork towards yellow; t = 0 original, t = 1 fully yellow. */
    private fun tintFilter(t: Float): ColorMatrixColorFilter {
        val rad = -142f * t * (PI.toFloat() / 180f)
        val cs = cos(rad)
        val sn = sin(rad)
        val lr = 0.213f
        val lg = 0.715f
        val lb = 0.072f
        val m = floatArrayOf(
            lr + cs * (1 - lr) + sn * (-lr), lg + cs * (-lg) + sn * (-lg), lb + cs * (-lb) + sn * (1 - lb), 0f, 0f,
            lr + cs * (-lr) + sn * 0.143f, lg + cs * (1 - lg) + sn * 0.140f, lb + cs * (-lb) + sn * (-0.283f), 0f, 0f,
            lr + cs * (-lr) + sn * (-(1 - lr)), lg + cs * (-lg) + sn * lg, lb + cs * (1 - lb) + sn * lb, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
        val cm = ColorMatrix(m)
        val g = 1f + 0.4f * t
        cm.postConcat(ColorMatrix().apply { setScale(g, g, g, 1f) })
        return ColorMatrixColorFilter(cm)
    }

    private fun drawSeg(c: Canvas, start: Float, length: Float, color: Int, w: Float) {
        val total = frameMeasure.length
        seg.rewind()
        val end = start + length
        if (end <= total) {
            frameMeasure.getSegment(start, end, seg, true)
        } else {
            frameMeasure.getSegment(start, total, seg, true)
            frameMeasure.getSegment(0f, end - total, seg, false)
        }
        glowPath(c, seg, color, w, 1f)
    }

    // ---------- icons ----------
    private fun iconCheck(c: Canvas, x: Float, y: Float, s: Float) {
        line.style = Paint.Style.STROKE; line.strokeWidth = s * 0.14f
        c.drawCircle(x, y, s, line)
        tmp.rewind()
        tmp.moveTo(x - s * 0.45f, y + s * 0.02f)
        tmp.lineTo(x - s * 0.1f, y + s * 0.38f)
        tmp.lineTo(x + s * 0.5f, y - s * 0.35f)
        c.drawPath(tmp, line)
    }

    private fun iconBell(c: Canvas, x: Float, y: Float, s: Float) {
        line.style = Paint.Style.STROKE; line.strokeWidth = s * 0.14f
        tmp.rewind()
        arcRect.set(x - s * 0.5f, y - s * 0.7f, x + s * 0.5f, y + s * 0.3f)
        tmp.arcTo(arcRect, 180f, 180f, true)
        tmp.lineTo(x + s * 0.62f, y + s * 0.5f)
        tmp.lineTo(x - s * 0.62f, y + s * 0.5f)
        tmp.close()
        c.drawPath(tmp, line)
        c.drawCircle(x, y + s * 0.78f, s * 0.14f, fill)
    }

    private fun iconList(c: Canvas, x: Float, y: Float, s: Float) {
        line.style = Paint.Style.STROKE; line.strokeWidth = s * 0.14f
        for (k in -1..1) {
            val yy = y + k * s * 0.55f
            c.drawCircle(x - s * 0.7f, yy, s * 0.14f, fill)
            c.drawLine(x - s * 0.35f, yy, x + s * 0.85f, yy, line)
        }
    }

    // ---------- layout ----------
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val ww = w.toFloat()
        val hh = h.toFloat()
        val m = ww * 0.012f
        val cut = ww * 0.085f
        framePath.set(chamfer(RectF(m, m, ww - m, hh - m), cut))
        frameInner.set(chamfer(RectF(m * 3.2f, m * 3.2f, ww - m * 3.2f, hh - m * 3.2f), cut * 0.8f))
        frameMeasure.setPath(framePath, true)
        dividerY = hh * 0.118f
        cx = ww / 2f
        cy = hh * 0.435f
        cr = min(ww * 0.34f, hh * 0.145f)
        val px = ww * 0.075f
        val spec = arrayOf(floatArrayOf(0.14f, 0.255f), floatArrayOf(0.655f, 0.775f), floatArrayOf(0.795f, 0.935f))
        for (i in 0..2) {
            panelRects[i].set(px, hh * spec[i][0], ww - px, hh * spec[i][1])
            panelPaths[i].set(chamfer(panelRects[i], ww * 0.035f))
        }
        gearRect.set(ww * 0.35f, hh * 0.945f, ww * 0.65f, hh * 0.985f)
        rebuild()
    }

    private fun bullets(lines: List<String>): String =
        if (lines.isEmpty()) "\u2014" else lines.joinToString("\n") { "\u2022 $it" }

    private fun clean(s: String): List<String> = s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    private fun contentFor(i: Int): String = when (i) {
        0 -> Store.hudTask.ifBlank { "\u2014" }
        1 -> bullets(clean(Store.hudReminders))
        else -> bullets(clean(Store.hudPlans) + plansCache)
    }

    private fun currentKey() =
        Store.hudTask + "|" + Store.hudReminders + "|" + Store.hudPlans + "|" + plansCache.joinToString(";")

    private fun rebuild() {
        if (width == 0) return
        val ww = width.toFloat()
        val ts = ww * 0.036f
        bodyPaint.textSize = ts
        bodyPaint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        bodyPaint.color = Color.parseColor("#BFEFFF")
        for (i in 0..2) {
            val r = panelRects[i]
            val availW = (r.width() - ww * 0.17f).toInt()
            val availH = r.height() - ww * 0.105f - ww * 0.03f
            val maxLines = max(1, (availH / (ts * 1.3f)).toInt())
            val txt = contentFor(i)
            layouts[i] = StaticLayout.Builder.obtain(txt, 0, txt.length, bodyPaint, availW)
                .setMaxLines(maxLines)
                .setEllipsize(TextUtils.TruncateAt.END)
                .setLineSpacing(0f, 1.05f)
                .build()
        }
        dataKey = currentKey()
    }

    private val refresh = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            if (now - plansAt > 60000) {
                plansCache = try {
                    Engine.todayEvents()
                } catch (e: Exception) {
                    emptyList()
                }
                plansAt = now
            }
            if (currentKey() != dataKey) rebuild()
            postDelayed(this, 1500)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(refresh)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(refresh)
        super.onDetachedFromWindow()
    }

    // ---------- touch ----------
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val x = e.x
            val y = e.y
            if (onGear != null && gearRect.contains(x, y)) {
                onGear?.invoke()
                return true
            }
            if (hypot(x - cx, y - cy) < cr * 1.1f) {
                onCore?.invoke()
                return true
            }
            for (i in 0..2) {
                if (onPanel != null && panelRects[i].contains(x, y)) {
                    onPanel?.invoke(i)
                    return true
                }
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            onHold?.invoke()
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean {
        gd.onTouchEvent(e)
        return true
    }

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        val ww = width.toFloat()
        val hh = height.toFloat()
        val now = System.nanoTime()
        val t = (now - t0) / 1e9f
        val dt = ((now - lastNs) / 1e9f).coerceIn(0f, 0.1f)
        lastNs = now

        val speaking = Engine.speaker.isSpeaking
        val thinking = Engine.thinking && !speaking
        tint += ((if (speaking) 1f else 0f) - tint) * min(1f, dt * 7f)
        val accent = mix(blue, yellow, tint)
        val deep = mix(blueDeep, yellowDeep, tint)

        // heartbeat while speaking: a smooth lub-dub pulse plus a small kick on each word
        var beat = 0f
        if (speaking) {
            val x = (t % 0.72f) / 0.72f
            beat = max(bump(x, 0.06f, 0.07f), 0.55f * bump(x, 0.32f, 0.08f))
            val since = (SystemClock.uptimeMillis() - Engine.speaker.lastKickMs).toFloat()
            if (since in 0f..450f) beat = max(beat, 0.8f * exp(-since / 110f))
        }
        smoothBeat += (beat - smoothBeat) * min(1f, dt * 20f)
        val breath = 1f + 0.012f * sin(t * 2f * PI.toFloat() / 3.6f)
        val scale = breath + 0.075f * smoothBeat
        rot += dt * (if (thinking) 70f else 9f)

        val sec = System.currentTimeMillis() / 1000
        if (sec != lastSec) {
            lastSec = sec
            val d = Date()
            dayS = dayFmt.format(d).uppercase(Locale.getDefault())
            dateS = dateFmt.format(d)
            timeS = timeFmt.format(d).uppercase(Locale.getDefault())
        }

        c.drawColor(Color.BLACK)

        // frame with a travelling light
        glowPath(c, framePath, blue, ww * 0.0035f, 0.85f + 0.15f * sin(t * 1.3f))
        line.style = Paint.Style.STROKE
        line.color = alphaOf(blue, 0.35f); line.strokeWidth = ww * 0.002f
        c.drawPath(frameInner, line)
        val total = frameMeasure.length
        drawSeg(c, (t * 0.07f % 1f) * total, total * 0.1f, mix(blue, Color.WHITE, 0.6f), ww * 0.004f)

        // header
        text.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        text.letterSpacing = 0.04f
        text.textAlign = Paint.Align.LEFT
        text.textSize = ww * 0.060f
        text.color = mix(blue, Color.WHITE, 0.45f)
        c.drawText(dayS, ww * 0.075f, hh * 0.052f, text)
        text.textSize = ww * 0.050f
        text.color = alphaOf(blue, 0.9f)
        c.drawText(dateS, ww * 0.075f, hh * 0.052f + ww * 0.07f, text)
        text.textAlign = Paint.Align.RIGHT
        text.textSize = ww * 0.085f
        text.color = mix(blue, Color.WHITE, 0.45f)
        c.drawText(timeS, ww * 0.925f, hh * 0.062f, text)

        line.style = Paint.Style.STROKE
        line.color = alphaOf(blue, 0.3f); line.strokeWidth = ww * 0.012f
        c.drawLine(ww * 0.06f, dividerY, ww * 0.94f, dividerY, line)
        line.color = alphaOf(blue, 0.85f); line.strokeWidth = ww * 0.003f
        c.drawLine(ww * 0.06f, dividerY, ww * 0.94f, dividerY, line)

        // wing lines with data pulses flowing into the reactor
        val x0 = ww * 0.03f
        val x1 = cx - cr * 1.2f
        line.color = alphaOf(blue, 0.55f); line.strokeWidth = ww * 0.003f
        c.drawLine(x0, cy, x1, cy, line)
        c.drawLine(ww - x0, cy, ww - x1, cy, line)
        for (n in 0..1) {
            val k = (t * 0.45f + n * 0.5f) % 1f
            fill.color = alphaOf(accent, 1f - 0.7f * k)
            c.drawCircle(x0 + (x1 - x0) * k, cy, ww * 0.009f, fill)
            c.drawCircle(ww - x0 - (x1 - x0) * k, cy, ww * 0.009f, fill)
        }

        // reactor halo
        val haloR = cr * (1.75f + 0.25f * smoothBeat)
        fill.shader = RadialGradient(
            cx, cy, haloR,
            intArrayOf(alphaOf(accent, 0.30f + 0.25f * smoothBeat), alphaOf(deep, 0.10f), alphaOf(deep, 0f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, haloR, fill)
        fill.shader = null

        // reactor artwork (hue-shifted to yellow while speaking, scaled by the beat)
        val rr = cr * scale
        dst.set(cx - rr, cy - rr, cx + rr, cy + rr)
        // cross-fade blue -> yellow (blue underneath, yellow on top) so it never passes through green
        if (tint < 0.999f) {
            bmp.colorFilter = null
            bmp.alpha = 255
            c.drawBitmap(core, null, dst, bmp)
        }
        if (tint > 0.001f) {
            bmp.colorFilter = yellowFilter
            bmp.alpha = (tint * 255f).toInt().coerceIn(0, 255)
            c.drawBitmap(core, null, dst, bmp)
        }

        // animated rings over and around the artwork
        val hi = mix(accent, Color.WHITE, 0.5f)
        ringArc(c, rr * 0.325f, rot * 3f, 55f, hi, rr * 0.016f)
        ringArc(c, rr * 0.325f, rot * 3f + 180f, 55f, hi, rr * 0.016f)
        ringArc(c, rr * 1.05f, -rot * 1.6f, 70f, accent, rr * 0.012f)
        ringArc(c, rr * 1.05f, -rot * 1.6f + 180f, 70f, accent, rr * 0.012f)
        ringArc(c, rr * 1.09f, rot * 0.9f + 40f, 25f, accent, rr * 0.010f)
        line.style = Paint.Style.STROKE
        line.strokeWidth = rr * 0.008f
        line.color = alphaOf(accent, 0.55f)
        for (k in 0 until 72) {
            val a = (k * 5f + rot * 0.3f) * (PI.toFloat() / 180f)
            val r0 = rr * 1.14f
            val r1 = r0 + rr * (if (k % 6 == 0) 0.05f else 0.025f)
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * r1, cy + sin(a) * r1, line)
        }

        // status line
        val status = when {
            speaking -> "SPEAKING"
            thinking -> "PROCESSING"
            Engine.serviceRunning -> "LISTENING \u2014 SAY \u201CHEY JARVIS\u201D"
            else -> "OFFLINE \u2014 TAP THE CORE TO START"
        }
        text.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        text.textAlign = Paint.Align.CENTER
        text.letterSpacing = 0.14f
        text.textSize = ww * 0.036f
        text.color = alphaOf(accent, 0.95f)
        c.drawText(status, cx, cy + cr * 1.32f, text)
        text.letterSpacing = 0.04f

        // panels
        for (i in 0..2) drawPanel(c, i, t, ww)

        if (onGear != null) {
            text.textAlign = Paint.Align.CENTER
            text.letterSpacing = 0.2f
            text.textSize = ww * 0.036f
            text.color = alphaOf(blue, 0.7f)
            c.drawText("[ SETUP ]", ww / 2f, hh * 0.972f, text)
            text.letterSpacing = 0.04f
        }

        postInvalidateOnAnimation()
    }

    private fun drawPanel(c: Canvas, i: Int, t: Float, ww: Float) {
        val r = panelRects[i]
        glowPath(c, panelPaths[i], blue, ww * 0.003f, 0.7f + 0.25f * sin(t * 1.4f + i * 1.7f))

        val ix = r.left + ww * 0.075f
        val iy = r.top + ww * 0.062f
        line.color = blue
        fill.color = blue
        when (i) {
            0 -> iconCheck(c, ix, iy, ww * 0.03f)
            1 -> iconBell(c, ix, iy, ww * 0.034f)
            else -> iconList(c, ix, iy, ww * 0.03f)
        }

        text.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        text.textAlign = Paint.Align.LEFT
        text.letterSpacing = 0.06f
        text.textSize = ww * 0.045f
        text.color = mix(blue, Color.WHITE, 0.45f)
        c.drawText(titles[i], r.left + ww * 0.13f, r.top + ww * 0.077f, text)
        text.letterSpacing = 0.04f

        line.style = Paint.Style.STROKE
        line.color = alphaOf(blue, 0.4f); line.strokeWidth = ww * 0.0025f
        c.drawLine(r.left + ww * 0.05f, r.top + ww * 0.094f, r.right - ww * 0.05f, r.top + ww * 0.094f, line)

        // [ brackets ]
        val by0 = r.top + ww * 0.108f
        val by1 = r.bottom - ww * 0.03f
        val bl = r.left + ww * 0.05f
        val br = r.right - ww * 0.05f
        val tick = ww * 0.018f
        line.color = alphaOf(blue, 0.9f); line.strokeWidth = ww * 0.0035f
        c.drawLine(bl, by0, bl, by1, line)
        c.drawLine(bl, by0, bl + tick, by0, line)
        c.drawLine(bl, by1, bl + tick, by1, line)
        c.drawLine(br, by0, br, by1, line)
        c.drawLine(br, by0, br - tick, by0, line)
        c.drawLine(br, by1, br - tick, by1, line)

        val lay = layouts[i]
        if (lay != null) {
            c.save()
            c.translate(r.left + ww * 0.085f, by0 + ww * 0.012f)
            lay.draw(c)
            c.restore()
        }
    }
}
