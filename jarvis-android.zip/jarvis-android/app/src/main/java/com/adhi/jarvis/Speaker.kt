package com.adhi.jarvis

import android.content.Context
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/** Deep British male text-to-speech. Reports speaking state so the HUD can turn yellow and beat. */
class Speaker(ctx: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ready = false
    private val queued = ArrayList<String>()
    private val active = AtomicInteger(0)

    /** Used by the mic service to pause listening while Jarvis talks. */
    @Volatile
    var onSpeaking: ((Boolean) -> Unit)? = null

    /** Uptime (ms) of the latest spoken word, so the HUD can add a kick on each word. */
    @Volatile
    var lastKickMs = 0L

    val isSpeaking: Boolean get() = active.get() > 0

    // Voice-name fragments of known male English voices (Google and Samsung engines).
    private val maleHints = listOf("-gbd-", "-gbb-", "-rjs-", "smtm")

    private fun isMale(v: Voice) = maleHints.any { v.name.lowercase(Locale.ROOT).contains(it) }

    /** Installed English voices: British male first, then other British, then the rest. */
    fun englishVoices(): List<Voice> {
        val all = tts?.voices ?: return emptyList()
        return all
            .filter { it.locale.language == "en" && !it.features.contains("notInstalled") }
            .sortedWith(compareBy<Voice>({ it.locale.country != "GB" }, { !isMale(it) }, { it.name }))
    }

    fun currentVoiceName(): String = tts?.voice?.name ?: ""

    fun useVoice(v: Voice) {
        tts?.setVoice(v)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.setLanguage(Locale.UK)
        val list = englishVoices()
        val saved = Store.voiceName
        val pick = list.firstOrNull { saved.isNotBlank() && it.name == saved } ?: list.firstOrNull()
        if (pick != null) t.setVoice(pick)
        t.setPitch(0.85f)
        t.setSpeechRate(0.96f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                onSpeaking?.invoke(true)
            }

            override fun onDone(utteranceId: String?) {
                finish()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish()
            }

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                lastKickMs = SystemClock.uptimeMillis()
            }
        })
        ready = true
        synchronized(queued) {
            queued.forEach { say(it) }
            queued.clear()
        }
    }

    private fun finish() {
        if (active.decrementAndGet() <= 0) {
            active.set(0)
            onSpeaking?.invoke(false)
        }
    }

    private fun say(text: String) {
        active.incrementAndGet()
        val r = tts?.speak(text, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        if (r != TextToSpeech.SUCCESS) finish()
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            synchronized(queued) { queued.add(text) }
            return
        }
        say(text)
    }
}
