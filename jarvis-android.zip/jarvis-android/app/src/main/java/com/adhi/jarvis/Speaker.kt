package com.adhi.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/** British-voiced text-to-speech. Reports start/stop so the mic can pause while Jarvis talks. */
class Speaker(ctx: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ready = false
    private val queued = ArrayList<String>()
    private val active = AtomicInteger(0)

    @Volatile
    var onSpeaking: ((Boolean) -> Unit)? = null

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.language = Locale.UK
        t.setPitch(0.9f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                onSpeaking?.invoke(true)
            }

            override fun onDone(utteranceId: String?) {
                finish()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish()
            }
        })
        ready = true
        synchronized(queued) {
            queued.forEach { say(it) }
            queued.clear()
        }
    }

    private fun finish() {
        if (active.decrementAndGet() <= 0) {
            active.set(0)
            onSpeaking?.invoke(false)
        }
    }

    private fun say(text: String) {
        active.incrementAndGet()
        val r = tts?.speak(text, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        if (r != TextToSpeech.SUCCESS) finish()
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            synchronized(queued) { queued.add(text) }
            return
        }
        say(text)
    }
}
