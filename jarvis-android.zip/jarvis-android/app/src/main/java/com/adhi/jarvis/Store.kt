package com.adhi.jarvis

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything Jarvis remembers on-device: settings, profile, knowledge notes, lifelog. */
object Store {
    private fun sp() = Engine.app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private fun str(k: String, d: String): String = sp().getString(k, d) ?: d
    private fun put(k: String, v: String) {
        sp().edit().putString(k, v.trim()).apply()
    }

    var apiKey: String
        get() = str("apiKey", "")
        set(v) = put("apiKey", v)

    var model: String
        get() = str("model", "").ifBlank { "claude-haiku-5-5" }
        set(v) = put("model", v)

    var dashboardUrl: String
        get() = str("dashboardUrl", "")
        set(v) = put("dashboardUrl", v)

    var profile: String
        get() = str("profile", "")
        set(v) = put("profile", v)

    var hudTask: String
        get() = str("hudTask", "")
        set(v) = put("hudTask", v)

    var hudReminders: String
        get() = str("hudReminders", "")
        set(v) = put("hudReminders", v)

    var hudPlans: String
        get() = str("hudPlans", "")
        set(v) = put("hudPlans", v)

    var voiceName: String
        get() = str("voiceName", "")
        set(v) = put("voiceName", v)

    private fun file(name: String) = File(Engine.app.filesDir, name)

    fun stamp(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date())

    fun appendLog(activity: String) {
        file("lifelog.txt").appendText(stamp() + " | " + activity.replace("\n", " ") + "\n")
    }

    fun addNote(note: String) {
        file("knowledge.txt").appendText(stamp().substring(0, 10) + ": " + note.replace("\n", " ") + "\n")
    }

    fun notes(n: Int = 40): String {
        val f = file("knowledge.txt")
        return if (f.exists()) f.readLines().takeLast(n).joinToString("\n") else ""
    }

    fun recentLog(n: Int = 12): String {
        val f = file("lifelog.txt")
        return if (f.exists()) f.readLines().takeLast(n).joinToString("\n") else ""
    }
}
