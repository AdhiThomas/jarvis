package com.adhi.jarvis

import org.json.JSONObject

/** Splits a Claude reply into the spoken text and the trailing raw-JSON action blocks. */
object Parser {
    fun split(reply: String): Pair<String, List<JSONObject>> {
        val actions = ArrayList<JSONObject>()
        val sb = StringBuilder()
        var i = 0
        while (i < reply.length) {
            val c = reply[i]
            if (c == '{') {
                val end = matchEnd(reply, i)
                if (end > 0) {
                    val obj = try {
                        JSONObject(reply.substring(i, end + 1))
                    } catch (e: Exception) {
                        null
                    }
                    if (obj != null && obj.has("action")) {
                        actions.add(obj)
                        i = end + 1
                        continue
                    }
                }
            }
            sb.append(c)
            i++
        }
        val spoken = sb.toString()
            .replace(Regex("```[a-zA-Z]*"), "")
            .replace(Regex("\\n{2,}"), "\n")
            .trim()
        return Pair(spoken, actions)
    }

    private fun matchEnd(s: String, start: Int): Int {
        var depth = 0
        var inStr = false
        var esc = false
        for (k in start until s.length) {
            val ch = s[k]
            if (inStr) {
                if (esc) esc = false
                else if (ch == '\\') esc = true
                else if (ch == '"') inStr = false
            } else {
                when (ch) {
                    '"' -> inStr = true
                    '{' -> depth++
                    '}' -> {
                        depth--
                        if (depth == 0) return k
                    }
                }
            }
        }
        return -1
    }
}
