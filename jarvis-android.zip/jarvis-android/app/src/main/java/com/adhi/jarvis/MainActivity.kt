package com.adhi.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** The J.A.R.V.I.S. home screen. Tap the core to start/stop listening, tap a panel to edit it. */
class MainActivity : Activity() {
    private lateinit var hud: HudScreenView
    private var autoStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hud = HudScreenView(this)
        hud.onGear = { startActivity(Intent(this, SetupActivity::class.java)) }
        hud.onCore = { toggle() }
        hud.onPanel = { i -> editPanel(i) }
        setContentView(hud)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onResume() {
        super.onResume()
        if (!autoStarted && !Engine.serviceRunning && micGranted()) {
            autoStarted = true
            startForegroundService(Intent(this, JarvisService::class.java))
        }
    }

    private fun micGranted() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toggle() {
        if (Engine.serviceRunning) {
            stopService(Intent(this, JarvisService::class.java))
        } else if (micGranted()) {
            startForegroundService(Intent(this, JarvisService::class.java))
        } else {
            Toast.makeText(this, "Grant the microphone in [ SETUP ] first, Sir.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SetupActivity::class.java))
        }
    }

    private fun editPanel(i: Int) {
        val titles = arrayOf("TODAY\u2019S TASK", "REMINDERS", "PLANS TODAY")
        val current = when (i) {
            0 -> Store.hudTask
            1 -> Store.hudReminders
            else -> Store.hudPlans
        }
        val box = EditText(this).apply {
            setText(current)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            hint = "One item per line"
        }
        AlertDialog.Builder(this)
            .setTitle(titles[i])
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val v = box.text.toString()
                when (i) {
                    0 -> Store.hudTask = v
                    1 -> Store.hudReminders = v
                    else -> Store.hudPlans = v
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
