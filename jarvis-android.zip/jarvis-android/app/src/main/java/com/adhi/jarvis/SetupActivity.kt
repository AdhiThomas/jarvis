package com.adhi.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Setup + command console. Everything Jarvis needs is switched on from here, once. */
class SetupActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var console: TextView
    private lateinit var keyF: EditText
    private lateinit var modelF: EditText
    private lateinit var dashF: EditText
    private lateinit var profF: EditText
    private lateinit var cmdF: EditText
    private lateinit var voiceL: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.parseColor("#00D4FF"))
        setPadding(0, dp(14), 0, dp(2))
    }

    private fun field(h: String, v: String, multi: Boolean = false, secret: Boolean = false) = EditText(this).apply {
        setHint(h)
        setText(v)
        if (multi) {
            minLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            setSingleLine()
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
    }

    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    private fun open(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open that screen: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 26f
            setTextColor(Color.parseColor("#00D4FF"))
        })
        status = TextView(this).apply { textSize = 12f }
        root.addView(status)

        root.addView(label("SETUP (once)"))
        root.addView(button("1 · Grant mic, calendar, location, notifications") {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ), 1
            )
        })
        root.addView(button("2 · Allow display over other apps") {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("3 · Allow all-files access") {
            open(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("4 · Enable accessibility service") {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("5 · Battery: don't restrict Jarvis") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(label("API KEY (Claude sk-ant-... or OpenRouter sk-or-...)"))
        keyF = field("sk-or-... or sk-ant-...", Store.apiKey, secret = true)
        root.addView(keyF)
        root.addView(label("MODEL"))
        modelF = field("claude-haiku-5-5", Store.model)
        root.addView(modelF)
        root.addView(label("DASHBOARD URL (optional, receives lifelog posts)"))
        dashF = field("https://my-dashboard.example.com", Store.dashboardUrl)
        root.addView(dashF)
        root.addView(label("PROFILE, GOALS & WORKFLOWS (Jarvis reads this every time)"))
        profF = field("Who you are, your goals, your routines...", Store.profile, multi = true)
        root.addView(profF)
        root.addView(button("Save settings") {
            save()
            Toast.makeText(this, "Saved, Sir.", Toast.LENGTH_SHORT).show()
        })

        root.addView(label("CONTROL"))
        root.addView(button("▶ Start Jarvis (listen for \"Hey Jarvis\")") { start() })
        root.addView(button("■ Stop Jarvis") { stopService(Intent(this, JarvisService::class.java)) })
        root.addView(button("Open HUD") { Engine.typed("Hey Jarvis, Daddy's home") })

        root.addView(label("VOICE"))
        voiceL = TextView(this).apply { textSize = 12f }
        root.addView(voiceL)
        root.addView(button("Next voice (tap until it sounds right)") { nextVoice() })

        root.addView(label("TYPE A COMMAND (no mic needed)"))
        cmdF = field("e.g. open YouTube", "")
        root.addView(cmdF)
        root.addView(button("Send") {
            val t = cmdF.text.toString().trim()
            if (t.isNotEmpty()) {
                cmdF.setText("")
                save()
                Engine.typed(t)
            }
        })

        root.addView(label("CONSOLE"))
        console = TextView(this).apply {
            textSize = 13f
            setTextIsSelectable(true)
        }
        root.addView(console)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        Store.apiKey = keyF.text.toString()
        Store.model = modelF.text.toString()
        Store.dashboardUrl = dashF.text.toString()
        Store.profile = profF.text.toString()
    }

    private fun start() {
        save()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Grant the microphone first (step 1).", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java))
    }

    private fun nextVoice() {
        val list = Engine.speaker.englishVoices()
        if (list.isEmpty()) {
            Toast.makeText(this, "The voice engine isn't ready yet, Sir.", Toast.LENGTH_LONG).show()
            return
        }
        val cur = list.indexOfFirst { it.name == Engine.speaker.currentVoiceName() }
        val v = list[(cur + 1) % list.size]
        Engine.speaker.useVoice(v)
        Store.voiceName = v.name
        voiceL.text = "Voice: " + v.name
        Engine.speaker.speak("Good evening, Sir. How does this voice sound?")
    }

    private fun refresh() {
        voiceL.text = "Voice: " + Engine.speaker.currentVoiceName()
        fun mark(b: Boolean) = if (b) "✓" else "✗"
        val mic = Engine.granted(Manifest.permission.RECORD_AUDIO)
        val cal = Engine.granted(Manifest.permission.WRITE_CALENDAR)
        status.text = "Mic " + mark(mic) + "   Calendar " + mark(cal) +
                "   Overlay " + mark(Settings.canDrawOverlays(this)) +
                "   Files " + mark(Engine.hasAllFiles()) +
                "   Accessibility " + mark(JarvisAccessibility.instance != null)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        console.text = Engine.console.joinToString("\n\n")
        Engine.onLine = { console.text = Engine.console.joinToString("\n\n") }
    }

    override fun onPause() {
        Engine.onLine = null
        save()
        super.onPause()
    }
}
