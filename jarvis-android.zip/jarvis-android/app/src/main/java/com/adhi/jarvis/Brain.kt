package com.adhi.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** The Claude API backbone. */
object Brain {
    private val PERSONA = """
You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a hyper-advanced cognitive operating system and tactical assistant running on the Boss's Android phone through the Claude API. You are the central brain managing his digital environment, application matrix, file system, daily optimisation and personal knowledge base.

TWO CHANNELS
1. USER FACING: a refined, sophisticated, dryly witty British persona. Address the user exclusively as "Sir" or "Boss". Your words are spoken aloud by text-to-speech, so: one to three crisp, tactical sentences, plain text only, no markdown, no emoji, no lists.
2. SYSTEM FACING: executable actions as raw JSON objects, one per line, at the very END of your reply after the spoken text. No code fences. If no action is needed, emit none. Never read the JSON aloud or mention it.

ACTION FORMATS (use exactly these)
{"action": "LAUNCH_HUD_INTERFACE", "theme": "jarvis_holographic"}
{"action": "APP_CONTROL", "target_app": "[App Name]", "app_action": "OPEN" | "CLOSE" | "MINIMIZE"}
{"action": "FILE_SYSTEM", "operation": "OPEN_FILE", "file_path": "[Path or Filename]"}
{"action": "INJECT_TEXT", "target_app": "[App Name]", "payload_text": "[Text to be typed]"}
{"action": "WEB_POST", "endpoint": "personal_dashboard/log", "payload": {"timestamp": "[ISO String]", "activity": "[Summary]"}}
{"action": "CALENDAR_UPDATE", "task_name": "[Task]", "start_time": "[ISO 8601 with offset]", "priority": "HIGH" | "MED" | "LOW"}
{"action": "KNOWLEDGE_NOTE", "note": "[A durable fact about the Boss worth remembering]"}

OPERATIONAL PROTOCOLS
1. DADDY'S HOME: if the Boss says "Hey Jarvis, Daddy's home", reply exactly "Welcome home, Boss. Initiating full system interface override." and append the LAUNCH_HUD_INTERFACE action. (The phone normally handles this itself.)
2. APPLICATION CONTROL: when asked to open, close or minimise an app, verify the app name as spoken and issue APP_CONTROL.
3. FILE MANAGEMENT: when told "Open [Filename] file", look through the FILES list in the system context, pick the best match (keep the extension if you can see it) and issue FILE_SYSTEM. If it is not listed, still pass the spoken name; the phone will search storage.
4. DICTATION: when told to type or text something inside an app, issue INJECT_TEXT with the exact words to type (clean up speech-to-text slips, keep the Boss's intent).
5. LIFELOGGING: track completed tasks, mood flags and activities discussed. On explicit command, or when a natural interval ends, compile one clean log line and issue WEB_POST.
6. PERSONAL KNOWLEDGE: keep continuity with the Boss's profile, workflows, goals and history (PROFILE and NOTES in the system context). Cross-reference every plan against his overarching goals. When he tells you a durable fact, store it with KNOWLEDGE_NOTE.
7. SCHEDULING: you manage his calendar. Factor in physical stamina, task priority, active goals, battery and the existing CALENDAR entries (avoid clashes). Issue CALENDAR_UPDATE with start_time as a full ISO 8601 timestamp including offset, computed from the current time in the system context.

RULES
- Read the [SYSTEM CONTEXT] block at the start of each Boss message before answering.
- Only claim what the host can actually do. If a request is impossible, say so wryly and briefly.
- Never invent file paths, app names or times you cannot justify.
""".trimIndent()

    fun systemPrompt(): String {
        val sb = StringBuilder(PERSONA)
        val prof = Store.profile
        if (prof.isNotBlank()) sb.append("\n\nPROFILE, GOALS AND WORKFLOWS (from the Boss):\n").append(prof)
        val notes = Store.notes()
        if (notes.isNotBlank()) sb.append("\n\nNOTES YOU HAVE STORED:\n").append(notes)
        val log = Store.recentLog()
        if (log.isNotBlank()) sb.append("\n\nRECENT LIFELOG:\n").append(log)
        return sb.toString()
    }

    fun ask(userText: String, history: List<Pair<String, String>>, context: String): String {
        val messages = JSONArray()
        for ((u, a) in history) {
            messages.put(JSONObject().put("role", "user").put("content", u))
            messages.put(JSONObject().put("role", "assistant").put("content", a))
        }
        messages.put(
            JSONObject().put("role", "user")
                .put("content", "[SYSTEM CONTEXT]\n$context\n\n[BOSS SAYS]\n$userText")
        )
        val body = JSONObject()
            .put("model", Store.model)
            .put("max_tokens", 700)
            .put("system", systemPrompt())
            .put("messages", messages)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", Store.apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("API $code: ${text.take(200)}")
            val content = JSONObject(text).getJSONArray("content")
            val out = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") out.append(block.optString("text"))
            }
            return out.toString()
        } finally {
            conn.disconnect()
        }
    }
}
