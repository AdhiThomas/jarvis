package com.adhi.jarvis

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/** Reads a string argument whether Claude put it at top level or inside "parameters". */
fun JSONObject.arg(key: String): String {
    val inner = optJSONObject("parameters")?.optString(key, "") ?: ""
    return inner.ifBlank { optString(key, "") }
}

/** Carries out the JSON actions Claude emits. Always call on the main thread. */
object Executor {
    private val main = Handler(Looper.getMainLooper())
    private val app: Context get() = Engine.app

    private fun tell(s: String) {
        Engine.say("Jarvis: $s")
        Engine.speaker.speak(s)
    }

    fun run(a: JSONObject) {
        try {
            when (a.optString("action").uppercase(Locale.ROOT)) {
                "LAUNCH_HUD_INTERFACE" -> launchHud()
                "APP_CONTROL" -> appControl(a.arg("target_app"), a.arg("app_action").uppercase(Locale.ROOT))
                "FILE_SYSTEM" -> openFile(a.arg("file_path"))
                "INJECT_TEXT" -> inject(a.arg("target_app"), a.arg("payload_text"))
                "WEB_POST" -> webPost(a)
                "CALENDAR_UPDATE" -> calendar(a)
                "KNOWLEDGE_NOTE" -> {
                    val n = a.arg("note")
                    if (n.isNotBlank()) Store.addNote(n)
                }
                else -> Engine.say("Unknown action: $a")
            }
        } catch (e: Exception) {
            Engine.say("Action failed: ${e.message}")
        }
    }

    // 1. HUD
    private fun launchHud() {
        if (!Settings.canDrawOverlays(app)) tell("Sir, I shall need permission to display over other apps for the full interface.")
        app.startActivity(
            Intent(app, HudActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    // 2. Application control
    private fun appControl(name: String, act: String) {
        when (act) {
            "OPEN" -> {
                val pkg = findApp(name) ?: return tell("I can't find an application called $name, Sir.")
                launch(pkg)
            }
            "MINIMIZE" -> app.startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "CLOSE" -> close(name)
            else -> Engine.say("Unknown app_action: $act")
        }
    }

    private fun findApp(query: String): String? {
        val q = query.lowercase(Locale.ROOT).trim()
        if (q.isBlank()) return null
        val pm = app.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null
        var bestScore = Int.MAX_VALUE
        for (r in list) {
            val label = r.loadLabel(pm).toString().lowercase(Locale.ROOT)
            val pkg = r.activityInfo.packageName
            val score = when {
                label == q -> 0
                label.contains(q) -> 10 + (label.length - q.length)
                q.contains(label) && label.length > 2 -> 100 + (q.length - label.length)
                pkg.lowercase(Locale.ROOT).contains(q.replace(" ", "")) -> 200
                else -> continue
            }
            if (score < bestScore) {
                bestScore = score
                best = pkg
            }
        }
        return best
    }

    private fun launch(pkg: String) {
        val i = app.packageManager.getLaunchIntentForPackage(pkg) ?: return tell("I can't launch that one, Sir.")
        app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun close(name: String) {
        val pkg = findApp(name) ?: return tell("I can't find an application called $name, Sir.")
        if (JarvisAccessibility.instance == null) {
            return tell("Closing applications needs my accessibility service, Sir. It appears to be offline.")
        }
        JarvisAccessibility.armForceStop()
        app.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // 3. Files
    private fun openFile(query: String) {
        if (!Engine.hasAllFiles()) return tell("I need all-files access to do that, Sir. It is in my setup screen.")
        val f = resolveFile(query) ?: return tell("I couldn't locate a file called $query, Sir.")
        val uri = FileProvider.getUriForFile(app, app.packageName + ".files", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            app.startActivity(i)
        } catch (e: ActivityNotFoundException) {
            tell("No application on this phone can open ${f.name}, Sir.")
        }
    }

    private fun resolveFile(query: String): File? {
        val direct = File(query)
        if (query.startsWith("/") && direct.isFile) return direct
        val root = Environment.getExternalStorageDirectory()
        val rel = File(root, query)
        if (rel.isFile) return rel
        val q = query.substringAfterLast('/').lowercase(Locale.ROOT).trim()
        if (q.isBlank()) return null
        var best: File? = null
        var bestScore = Int.MAX_VALUE
        root.walkTopDown().maxDepth(7)
            .onEnter { it.name != "Android" && !it.name.startsWith(".") }
            .filter { it.isFile }
            .forEach { f ->
                val n = f.name.lowercase(Locale.ROOT)
                val bare = f.nameWithoutExtension.lowercase(Locale.ROOT)
                val score = when {
                    n == q || bare == q -> 0
                    n.contains(q) -> 10 + (n.length - q.length)
                    else -> -1
                }
                if (score >= 0 && score < bestScore) {
                    bestScore = score
                    best = f
                }
            }
        return best
    }

    // 4. Dictation
    private fun inject(appName: String, text: String) {
        if (JarvisAccessibility.instance == null) {
            return tell("Typing into other applications needs my accessibility service, Sir.")
        }
        var delay = 0L
        if (appName.isNotBlank()) {
            val pkg = findApp(appName)
            if (pkg != null && JarvisAccessibility.lastPackage != pkg) {
                launch(pkg)
                delay = 1800
            }
        }
        tryInject(text, 0, delay)
    }

    private fun tryInject(text: String, attempt: Int, delay: Long) {
        main.postDelayed({
            val ok = JarvisAccessibility.instance?.inject(text) ?: false
            if (!ok) {
                if (attempt < 5) tryInject(text, attempt + 1, 700)
                else tell("I couldn't find a text field to type into, Sir.")
            }
        }, delay)
    }

    // 5. Lifelog
    private fun webPost(a: JSONObject) {
        val payload = a.optJSONObject("payload")
            ?: a.optJSONObject("parameters")?.optJSONObject("payload")
            ?: JSONObject().put("timestamp", Store.stamp()).put("activity", a.arg("activity"))
        val activity = payload.optString("activity", "")
        if (activity.isNotBlank()) Store.appendLog(activity)
        val base = Store.dashboardUrl
        if (base.isBlank()) {
            Engine.say("Lifelog saved on this phone (no dashboard URL set).")
            return
        }
        val url = base.trimEnd('/') + "/" + a.arg("endpoint").trimStart('/')
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                Engine.say("Dashboard sync: HTTP " + c.responseCode)
                c.disconnect()
            } catch (e: Exception) {
                Engine.say("Dashboard sync failed: ${e.message}")
            }
        }.start()
    }

    // 7. Calendar
    private fun calendar(a: JSONObject) {
        val title = a.arg("task_name").ifBlank { "Jarvis task" }
        val start = parseTime(a.arg("start_time")) ?: return tell("I couldn't make sense of that time, Sir.")
        val end = start + 60L * 60 * 1000
        val priority = a.arg("priority").ifBlank { "MED" }
        val canWrite = Engine.granted(Manifest.permission.READ_CALENDAR) && Engine.granted(Manifest.permission.WRITE_CALENDAR)
        val calId = if (canWrite) writableCalendarId() else null
        if (calId != null) {
            val v = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, start)
                put(CalendarContract.Events.DTEND, end)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, "Priority: $priority (scheduled by J.A.R.V.I.S.)")
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            app.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v)
            Engine.say("Calendar: added \"$title\" [$priority]")
        } else {
            app.startActivity(
                Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun writableCalendarId(): Long? {
        app.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID),
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= ?",
            arrayOf("500"),
            CalendarContract.Calendars.IS_PRIMARY + " DESC"
        )?.use { c -> if (c.moveToFirst()) return c.getLong(0) }
        return null
    }

    private fun parseTime(s: String): Long? {
        val str = s.trim()
        if (str.isEmpty()) return null
        val full = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mmXXX",
            "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm", "yyyy-MM-dd HH:mm"
        )
        for (p in full) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                f.isLenient = false
                val d = f.parse(str)
                if (d != null) return d.time
            } catch (e: ParseException) {
            }
        }
        for (p in listOf("HH:mm", "h:mm a", "hh:mm a", "h a")) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                f.isLenient = false
                val t = f.parse(str.uppercase(Locale.ROOT)) ?: continue
                val tc = Calendar.getInstance().apply { time = t }
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, tc.get(Calendar.HOUR_OF_DAY))
                    set(Calendar.MINUTE, tc.get(Calendar.MINUTE))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (cal.timeInMillis < System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
                return cal.timeInMillis
            } catch (e: ParseException) {
            }
        }
        return null
    }
}
