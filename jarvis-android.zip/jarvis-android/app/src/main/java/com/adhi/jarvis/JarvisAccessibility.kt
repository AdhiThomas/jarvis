package com.adhi.jarvis

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets Jarvis type into other apps and force-stop apps on command. */
class JarvisAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibility? = null

        @Volatile
        var lastPackage: String? = null

        /** 0 = idle, 1 = looking for "Force stop", 2 = confirming the dialog. */
        @Volatile
        var stage = 0
        private val handler = Handler(Looper.getMainLooper())

        fun armForceStop() {
            stage = 1
            handler.postDelayed({ stage = 0 }, 10000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            if (p != null && p != "com.android.systemui") lastPackage = p
        }
        if (stage == 0) return
        val root = rootInActiveWindow ?: return
        if (stage == 1) {
            if (clickByText(root, "force stop", false)) stage = 2
        } else if (stage == 2) {
            if (clickByText(root, "OK", true) || clickByText(root, "force stop", false)) {
                stage = 0
                handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 600)
            }
        }
    }

    private fun clickByText(root: AccessibilityNodeInfo, text: String, exact: Boolean): Boolean {
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            if (exact && !n.text.toString().equals(text, ignoreCase = true)) continue
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur = cur.parent
            }
        }
        return false
    }

    /** Types [text] into the focused (or first) editable field of the active window. */
    fun inject(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val base = if (target.isShowingHintText) "" else (target.text?.toString() ?: "")
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findEditable(c)
            if (r != null) return r
        }
        return null
    }
}
