package com.adhi.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Keeps the microphone listening for "Hey Jarvis" while the phone is awake. */
class JarvisService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var running = false
    private var paused = false
    private var listening = false

    private val speechIntent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private val startRunnable = Runnable {
        if (running && !paused && !listening) {
            try {
                listening = true
                rec?.startListening(speechIntent)
            } catch (e: Exception) {
                listening = false
                schedule(1500)
            }
        }
    }

    private fun schedule(ms: Long) {
        if (!running) return
        main.removeCallbacks(startRunnable)
        if (!paused) main.postDelayed(startRunnable, ms)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            listening = false
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                Engine.say("Microphone permission is missing, Sir.")
                stopSelf()
                return
            }
            schedule(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 350)
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) Engine.heard(t)
            schedule(300)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (!running) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                Engine.say("Speech recognition is not available on this phone.")
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            Engine.speaker.onSpeaking = { speaking ->
                main.post {
                    paused = speaking
                    if (speaking) {
                        main.removeCallbacks(startRunnable)
                        rec?.cancel()
                        listening = false
                    } else {
                        schedule(700)
                    }
                }
            }
            rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            Engine.say("Jarvis online. Listening for \"Hey Jarvis\".")
            schedule(200)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy()
        rec = null
        Engine.speaker.onSpeaking = null
        Engine.say("Jarvis offline.")
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("J.A.R.V.I.S. online")
            .setContentText("Listening for \"Hey Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }
}
