# J.A.R.V.I.S. — Android app (Claude API backbone)

## Get the APK (no Android Studio needed)
1. Create a free GitHub account and a new repository (e.g. `jarvis`).
2. Upload everything in this folder to the repo (drag the files/folders in on github.com -> Add file -> Upload files).
   If `.github` doesn't upload, use Add file -> Create new file, name it `.github/workflows/build.yml`
   and paste the contents of `workflow-build.yml`.
3. Open the repo's **Actions** tab -> "Build APK" -> wait ~5 minutes for the green tick.
4. Open the finished run -> **Artifacts** -> download `jarvis-apk` -> unzip -> install `app-debug.apk` on the phone
   (allow "install unknown apps" when asked).

## First launch
Tap steps 1-5 on the screen, paste your Claude API key, tap Save, then Start Jarvis.
Say "Hey Jarvis, Daddy's home" (screen on) or type commands in the box.
If the build fails, copy the red error text from the Actions log and send it back.
